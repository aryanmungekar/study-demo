---
layout: default
title: Home
---

<style>
    #breadcrumb a {
      color: #007BFF;
      text-decoration: none;
      margin-right: 5px;
    }
    #breadcrumb a:hover {
      text-decoration: underline;
    }
    #breadcrumb span {
      font-weight: bold;
      color: #333;
    }
  </style>

 <!-- ✅ Breadcrumb goes here -->
  <nav id="breadcrumb" style="font-family: sans-serif; font-size: 14px; margin: 10px 0;"></nav>
  <script>
    const baseUrl = "/study-demo";
    const path = window.location.pathname;
    const segments = path.replace(/\/$/, "").split("/");
    const startIndex = segments.indexOf("study-demo");
    let breadcrumbHtml = '';
    let fullPath = "";
    for (let i = startIndex; i < segments.length; i++) {
      const name = segments[i].replace(/-/g, " ").replace(/\b\w/g, c => c.toUpperCase());
      fullPath += '/' + segments[i];
      if (i === segments.length - 1) {
        breadcrumbHtml += `<span>${name}</span>`;
      } else {
        breadcrumbHtml += `<a href="${fullPath}/">${name}</a> &gt; `;
      }
    }
    document.getElementById("breadcrumb").innerHTML = breadcrumbHtml;
  </script>

<br><br><br><br><br><br><br><br><br><br><br>
<div><center>
  <button><a href="subject-1"><h3>subject1</h3></a></button><br>
  <button><a href="subject-2"><h3>subject2</h3></a></button><br>
  <button><a href="subject-3"><h3>subject3</h3></a></button><br>
  <button><a href="subject-4"><h3>subject4</h3></a></button><br>
  <button><a href="subject-5"><h3>subject5</h3></a></button>
  
</div>
