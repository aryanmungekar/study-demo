gem install bundler jekyll

bundle exec jekyll serve

source "https://rubygems.org"
gem "jekyll", "~> 4.3.2"
gem "webrick" # Required for Ruby ≥ 3.0

