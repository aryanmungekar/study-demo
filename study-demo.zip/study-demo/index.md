---
layout: default
title: Home
---

<div class="slider-container">
  <img class="slider-image" id="slider" src="{{ site.baseurl }}/assets/images/slider1.jpg" alt="Slide 1">
</div>

<h2>Pattern 2019</h2>
<div class="branch-grid">
  <a class="branch-btn" href="{{ site.baseurl }}/2019pattern/first-year">🧠 First Year</a>
  <a class="branch-btn" href="{{ site.baseurl }}/computer-science/">💻 Computer Science</a>
  <a class="branch-btn" href="{{ site.baseurl }}/it/">💽 Information Technology</a>
  <a class="branch-btn" href="{{ site.baseurl }}/aids/">🤖 AI & Data Science</a>
  <a class="branch-btn" href="{{ site.baseurl }}/first-year/">🧠 First Year</a>
  <a class="branch-btn" href="{{ site.baseurl }}/computer-science/">💻 Computer Science</a>
  <a class="branch-btn" href="{{ site.baseurl }}/it/">💽 Information Technology</a>
  <a class="branch-btn" href="{{ site.baseurl }}/aids/">🤖 AI & Data Science</a>
  <a class="branch-btn" href="{{ site.baseurl }}/first-year/">🧠 First Year</a>
  <a class="branch-btn" href="{{ site.baseurl }}/computer-science/">💻 Computer Science</a>
  <a class="branch-btn" href="{{ site.baseurl }}/it/">💽 Information Technology</a>
  <a class="branch-btn" href="{{ site.baseurl }}/aids/">🤖 AI & Data Science</a>
</div>
